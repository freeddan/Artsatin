<?php 
	use PHPMailer\PHPMailer\PHPMailer;

	require_once 'phpmailer/src/Exception.php';
	require_once 'phpmailer/src/SMTP.php';
	require_once 'phpmailer/src/PHPMailer.php';


	$mail = new PHPMailer();

	$mail->isSMTP();
	$mail->HOST = 'smtp.ukr.net';
	$mail->SMTPAuth = true;
	$mail->Username = 'artsatin248@artsatinn.zzz.com.ua';
	$mail->Password = '';
	$mail->Port = 465;
	$mail->SMTPSecure = "ssl";


	$mail->isHTML(true);
	$mail->setFrom($_POST['email'], $_POST['name']);
	$mail->addAddress("artsatin_mail@ukr.net");
	$mail->Subject = ("GG");
	$body = '<h1>О даа, новый заказ</h1>';

	if (trim(!empty($_POST['name']))){
		$body.='<p><strong>Имя:</strong> '.$_POST['name'].'</p>';
	}

	if (trim(!empty($_POST['email']))){
		$body.='<p><strong>Email:</strong> '.$_POST['email'].'</p>';
	}

	
	if (trim(!empty($_POST['tel']))){
		$body.='<p><strong>Телефон:</strong> '.$_POST['tel'].'</p>';
	}

	$body.='<p><strong>Сообщение:</strong> '.$_POST['mes'].'</p>';


	$mail->Body = $body;

	if (!$mail->send()) {
		$message = 'Ошибка';
	} else {
		$message = 'Данные отправлены!';

	}

	$response = ['message' => $message];

	header('Content-type: application/json');
	echo json_encode($response);
?>