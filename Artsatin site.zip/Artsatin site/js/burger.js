$(document).ready(function () {
    $('.header__burger').click(function (event) {
        $('.header__burger,.burger__menu').toggleClass('active')
        $('body').toggleClass('lock')
        $('footer').toggleClass('blur')
        $('main').toggleClass('blur')
        $('.logo').toggleClass('blur')
    });

    $('.burger__links a').click(function (event) {
        $('.header__burger,.burger__menu').toggleClass('active')
        $('body').toggleClass('lock')
        $('footer').toggleClass('blur')
        $('main').toggleClass('blur')
        $('.logo').toggleClass('blur')
    });
});