/*-------------CUPBOARD-------------*/


const imagesCup = document.querySelectorAll('.cupboard-slider-img');
const sliderLineCup = document.querySelector('.cupboard__slider__line');
let countCup = 0;
let widthCup;

function initCup() {
	console.log('resize');
	widthCup = document.querySelector('.cupboard-slider__wrapper').offsetWidth;
	sliderLineCup.style.width = widthCup * imagesCup.length + 'px';
	imagesCup.forEach(item => {
		item.style.width = widthCup + 'px';
		item.style.height = 'auto';
	});
	rollSliderCup();
}

initCup();
window.addEventListener('resize', initCup);

document.querySelector('.cupboard-arrowright').addEventListener('click', function () {
	countCup++;
	if (countCup >= imagesCup.length) {
		countCup = 0;
	}
	rollSliderCup();
});

document.querySelector('.cupboard-arrowleft').addEventListener('click', function () {
	countCup--;
	if (countCup < 0) {
		countCup = imagesCup.length - 1;
	}
	rollSliderCup();
});

function rollSliderCup() {
	sliderLineCup.style.transform = 'translate(-' + countCup * widthCup + 'px)';

}



/*-------------HALLWAY-------------*/

const imagesHall = document.querySelectorAll('.hallway-slider-img');
const sliderLineHall = document.querySelector('.hallway__slider__line');
let countHall = 0;
let widthHall;

function initHall() {
	console.log('resize');
	widthHall = document.querySelector('.hallway-slider__wrapper').offsetWidth;
	sliderLineHall.style.widthHall = widthHall * imagesHall.length + 'px';
	imagesHall.forEach(item => {
		item.style.width = widthHall + 'px';
		item.style.height = 'auto';
	});
	rollSliderHall();
}

initHall();
window.addEventListener('resize', initHall);

document.querySelector('.hallway-arrowright').addEventListener('click', function () {
	countHall++;
	if (countHall >= imagesHall.length) {
		countHall = 0;
	}
	rollSliderHall();
});

document.querySelector('.hallway-arrowleft').addEventListener('click', function () {
	countHall--;
	if (countHall < 0) {
		countHall = imagesHall.length - 1;
	}
	rollSliderHall();
});

function rollSliderHall() {
	sliderLineHall.style.transform = 'translate(-' + countHall * widthHall + 'px)';

}


/*-------------KITCHEN-------------*/


const imagesKit = document.querySelectorAll('.kitchen-slider-img');
const sliderLineKit = document.querySelector('.kitchen__slider__line');
let countKit = 0;
let widthKit;

function initKit() {
	console.log('resize');
	widthKit = document.querySelector('.kitchen-slider__wrapper').offsetWidth;
	sliderLineKit.style.width = widthKit * imagesKit.length + 'px';
	imagesKit.forEach(item => {
		item.style.width = widthKit + 'px';
		item.style.height = 'auto';
	});
	rollSliderKit();
}

initKit();
window.addEventListener('resize', initKit);

document.querySelector('.kitchen-arrowright').addEventListener('click', function () {
	countKit++;
	if (countKit >= imagesKit.length) {
		countKit = 0;
	}
	rollSliderKit();
});

document.querySelector('.kitchen-arrowleft').addEventListener('click', function () {
	countKit--;
	if (countKit < 0) {
		countKit = imagesKit.length - 1;
	}
	rollSliderKit();
});

function rollSliderKit() {
	sliderLineKit.style.transform = 'translate(-' + countKit * widthKit + 'px)';

}





