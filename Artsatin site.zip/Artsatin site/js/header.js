window.onscroll = function () {
	var scrolled = window.pageYOffset || document.documentElement.scrollTop; // Получаем положение скролла
	if (scrolled > 400 && screen.width < 801) {
		// Если прокрутка есть, то делаем блок прозрачным
		document.querySelector('.header').style.position = 'fixed';
		document.querySelector('.header').style.background = 'rgb(251, 248, 247,0.8)';
		document.querySelector("#btnScrollToTop").style.display = 'flex';
	} else {
		// Если нет, то делаем его полностью видимым
		document.querySelector('.header').style.position = 'absolute';
		document.querySelector('.header').style.background = 'none';
		document.querySelector("#btnScrollToTop").style.display = 'none';
	};
	if (scrolled > 400) {
		// Если прокрутка есть, то делаем блок прозрачным
		document.querySelector("#btnScrollToTop").style.display = 'flex';
	} else {
		// Если нет, то делаем его полностью видимым
		document.querySelector("#btnScrollToTop").style.display = 'none';
	};
};